import { Outlet, Link, useLocation } from "react-router-dom";
import { Home, MessageCircle, Compass, User, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

export default function Layout() {
  const location = useLocation();
  const { signOut } = useAuth();

  const navItems = [
    { icon: Home, label: "Feed", path: "/" },
    { icon: MessageCircle, label: "Messages", path: "/messages" },
    { icon: Compass, label: "Explore", path: "/explore" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full glass-effect">
        <div className="container max-w-screen-xl mx-auto flex h-16 items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 gradient-brand rounded-xl flex items-center justify-center shadow-elegant transition-bounce group-hover:scale-110">
              <MessageCircle className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold gradient-text">Yumi</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="default"
                    className={cn(
                      "gap-2 rounded-xl transition-smooth",
                      isActive && "gradient-brand shadow-elegant"
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="hidden lg:inline font-semibold">{item.label}</span>
                  </Button>
                </Link>
              );
            })}
            <Button
              variant="ghost"
              size="default"
              onClick={signOut}
              className="gap-2 ml-2 rounded-xl hover:bg-destructive/10 hover:text-destructive"
            >
              <LogOut className="w-5 h-5" />
              <span className="hidden lg:inline font-semibold">Sign Out</span>
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-screen-lg mx-auto px-4 py-8">
        <Outlet />
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 glass-effect">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path} className="flex-1">
                <button
                  className={cn(
                    "w-full flex flex-col items-center justify-center gap-1 py-2 rounded-xl transition-smooth",
                    isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Icon className={cn("w-6 h-6 transition-bounce", isActive && "scale-110")} />
                  <span className="text-xs font-semibold">{item.label}</span>
                </button>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
