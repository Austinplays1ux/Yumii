import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Edit2, Heart } from "lucide-react";

interface Profile {
  username: string;
  full_name: string | null;
  bio: string | null;
  avatar_url: string | null;
}

interface Post {
  id: string;
  caption: string;
  created_at: string;
  likes: { id: string }[];
}

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ full_name: "", bio: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);

  useEffect(() => {
    fetchProfile();
    fetchPosts();
    fetchFollowCounts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user?.id)
        .single();

      if (error) throw error;
      setProfile(data);
      setEditData({
        full_name: data.full_name || "",
        bio: data.bio || "",
      });
    } catch (error) {
      toast.error("Failed to load profile");
    } finally {
      setLoading(false);
    }
  };

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(
          `
          id,
          caption,
          created_at,
          likes (id)
        `
        )
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      toast.error("Failed to load posts");
    }
  };

  const fetchFollowCounts = async () => {
    try {
      const { data: followers } = await supabase
        .from("follows")
        .select("id")
        .eq("following_id", user?.id);

      const { data: following } = await supabase
        .from("follows")
        .select("id")
        .eq("follower_id", user?.id);

      setFollowerCount(followers?.length || 0);
      setFollowingCount(following?.length || 0);
    } catch (error) {
      console.error("Failed to fetch follow counts");
    }
  };

  const saveProfile = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: editData.full_name,
          bio: editData.bio,
        })
        .eq("id", user?.id);

      if (error) throw error;

      toast.success("Profile updated!");
      setIsEditing(false);
      fetchProfile();
    } catch (error) {
      toast.error("Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 md:pb-6">
      {/* Profile Card */}
      <Card className="p-8 rounded-2xl shadow-card border border-border hover-lift">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="relative">
            <Avatar className="w-28 h-28 ring-4 ring-accent shadow-elegant">
              <AvatarImage src={profile?.avatar_url || undefined} />
              <AvatarFallback className="gradient-brand text-primary-foreground text-3xl font-bold">
                {profile?.username[0].toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-2 -right-2 w-10 h-10 gradient-brand rounded-full flex items-center justify-center shadow-elegant">
              <Edit2 className="w-5 h-5 text-primary-foreground" />
            </div>
          </div>

          {!isEditing ? (
            <>
              <div className="space-y-2">
                <h1 className="text-3xl font-bold gradient-text">@{profile?.username}</h1>
                {profile?.full_name && (
                  <p className="text-lg text-muted-foreground font-medium">{profile.full_name}</p>
                )}
              </div>

              {profile?.bio && (
                <p className="text-foreground max-w-md text-base leading-relaxed px-4">
                  {profile.bio}
                </p>
              )}

              <div className="flex gap-8 pt-4">
                <div className="text-center">
                  <p className="text-3xl font-bold gradient-text">{posts.length}</p>
                  <p className="text-sm text-muted-foreground font-semibold">Posts</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold gradient-text">{followerCount}</p>
                  <p className="text-sm text-muted-foreground font-semibold">Followers</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold gradient-text">{followingCount}</p>
                  <p className="text-sm text-muted-foreground font-semibold">Following</p>
                </div>
              </div>

              <Button
                variant="gradient"
                size="lg"
                onClick={() => setIsEditing(true)}
                className="gap-2 px-8 shadow-elegant"
              >
                <Edit2 className="w-5 h-5" />
                Edit Profile
              </Button>
            </>
          ) : (
            <div className="w-full max-w-md space-y-6">
              <div className="space-y-2 text-left">
                <Label className="text-base font-semibold">Full Name</Label>
                <Input
                  value={editData.full_name}
                  onChange={(e) =>
                    setEditData({ ...editData, full_name: e.target.value })
                  }
                  placeholder="Your full name"
                  className="rounded-xl h-12 text-base"
                />
              </div>

              <div className="space-y-2 text-left">
                <Label className="text-base font-semibold">Bio</Label>
                <Textarea
                  value={editData.bio}
                  onChange={(e) =>
                    setEditData({ ...editData, bio: e.target.value })
                  }
                  placeholder="Tell us about yourself..."
                  className="rounded-xl resize-none text-base"
                  rows={4}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  variant="gradient"
                  onClick={saveProfile}
                  disabled={saving}
                  className="flex-1 h-12 shadow-elegant"
                >
                  {saving ? "Saving..." : "Save Changes"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEditing(false);
                    setEditData({
                      full_name: profile?.full_name || "",
                      bio: profile?.bio || "",
                    });
                  }}
                  className="flex-1 h-12 rounded-xl"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Posts Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <span className="gradient-text">Your Posts</span>
          <span className="text-muted-foreground text-lg">({posts.length})</span>
        </h2>
        <div className="grid gap-4">
          {posts.map((post) => (
            <Card key={post.id} className="p-6 rounded-2xl shadow-card border border-border hover-lift">
              <p className="text-foreground mb-3 text-base leading-relaxed">{post.caption}</p>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground font-medium">
                  {new Date(post.created_at).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <div className="flex items-center gap-2 text-primary font-semibold">
                  <Heart className="w-5 h-5 fill-current" />
                  <span>{post.likes.length}</span>
                </div>
              </div>
            </Card>
          ))}

          {posts.length === 0 && (
            <Card className="text-center py-16 rounded-2xl shadow-card border border-border">
              <div className="space-y-2">
                <p className="text-lg font-semibold text-foreground">No posts yet</p>
                <p className="text-muted-foreground">Share your first post with the community!</p>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
