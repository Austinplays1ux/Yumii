import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Conversation {
  id: string;
  updated_at: string;
  other_user: {
    id: string;
    username: string;
    avatar_url: string | null;
  };
  last_message?: {
    content: string;
    created_at: string;
  };
}

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
  profiles: {
    username: string;
    avatar_url: string | null;
  };
}

export default function Messages() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConversations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation);

      // Subscribe to new messages
      const channel = supabase
        .channel(`messages-${selectedConversation}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "messages",
            filter: `conversation_id=eq.${selectedConversation}`,
          },
          (payload) => {
            fetchMessages(selectedConversation);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedConversation]);

  const fetchConversations = async () => {
    try {
      const { data: participantsData, error } = await supabase
        .from("conversation_participants")
        .select(
          `
          conversation_id,
          conversations (id, updated_at)
        `
        )
        .eq("user_id", user?.id);

      if (error) throw error;

      // For each conversation, get the other participant and last message
      const conversationsWithDetails = await Promise.all(
        (participantsData || []).map(async (p: { conversation_id: string; conversations: { id: string; updated_at: string } }) => {
          const convId = p.conversations.id;

          // Get other participant
          const { data: otherParticipant } = await supabase
            .from("conversation_participants")
            .select("user_id, profiles (id, username, avatar_url)")
            .eq("conversation_id", convId)
            .neq("user_id", user?.id)
            .single();

          // Get last message
          const { data: lastMsg } = await supabase
            .from("messages")
            .select("content, created_at")
            .eq("conversation_id", convId)
            .order("created_at", { ascending: false })
            .limit(1)
            .single();

          return {
            id: convId,
            updated_at: p.conversations.updated_at,
            other_user: otherParticipant?.profiles || {
              id: "",
              username: "Unknown",
              avatar_url: null,
            },
            last_message: lastMsg || undefined,
          };
        })
      );

      setConversations(conversationsWithDetails);
    } catch (error) {
      toast.error("Failed to load conversations");
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (conversationId: string) => {
    try {
      const { data, error } = await supabase
        .from("messages")
        .select(
          `
          *,
          profiles (username, avatar_url)
        `
        )
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      toast.error("Failed to load messages");
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return;

    try {
      const { error } = await supabase.from("messages").insert({
        conversation_id: selectedConversation,
        sender_id: user?.id,
        content: newMessage,
      });

      if (error) throw error;

      setNewMessage("");
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  const selectedConv = conversations.find((c) => c.id === selectedConversation);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto pb-20 md:pb-6">
      <Card className="rounded-3xl shadow-card overflow-hidden border border-border">
        <div className="flex h-[650px]">
          {/* Conversations List */}
          <div
            className={cn(
              "w-full md:w-96 border-r border-border bg-card",
              selectedConversation && "hidden md:block"
            )}
          >
            <div className="p-6 border-b border-border">
              <h2 className="text-2xl font-bold gradient-text">Messages</h2>
            </div>
            <ScrollArea className="h-[calc(650px-89px)]">
              {conversations.length === 0 ? (
                <div className="p-8 text-center space-y-3">
                  <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground opacity-50" />
                  <div>
                    <p className="font-semibold text-foreground">No conversations yet</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Start by exploring and connecting with others
                    </p>
                  </div>
                </div>
              ) : (
                <div>
                  {conversations.map((conv) => (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv.id)}
                      className={cn(
                        "w-full p-4 flex items-center gap-3 hover:bg-accent transition-smooth border-b border-border/50",
                        selectedConversation === conv.id && "bg-accent border-l-4 border-l-primary"
                      )}
                    >
                      <Avatar className="w-14 h-14 ring-2 ring-accent">
                        <AvatarImage src={conv.other_user.avatar_url || undefined} />
                        <AvatarFallback className="gradient-brand text-primary-foreground font-bold">
                          {conv.other_user.username[0].toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-left min-w-0">
                        <p className="font-bold text-foreground truncate text-base">
                          {conv.other_user.username}
                        </p>
                        {conv.last_message && (
                          <p className="text-sm text-muted-foreground truncate">
                            {conv.last_message.content}
                          </p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Chat Area */}
          <div className={cn("flex-1 flex flex-col bg-gradient-to-br from-background to-accent/5", !selectedConversation && "hidden md:flex")}>
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b border-border flex items-center gap-3 bg-card">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="md:hidden rounded-xl"
                    onClick={() => setSelectedConversation(null)}
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <Avatar className="w-12 h-12 ring-2 ring-accent">
                    <AvatarImage src={selectedConv?.other_user.avatar_url || undefined} />
                    <AvatarFallback className="gradient-brand text-primary-foreground font-bold">
                      {selectedConv?.other_user.username[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="font-bold text-lg">@{selectedConv?.other_user.username}</h3>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-6">
                  <div className="space-y-4">
                    {messages.map((message) => {
                      const isOwn = message.sender_id === user?.id;
                      return (
                        <div key={message.id} className={cn("flex", isOwn ? "justify-end" : "justify-start")}>
                          <div
                            className={cn(
                              "max-w-[75%] rounded-2xl px-4 py-3 shadow-card",
                              isOwn
                                ? "gradient-brand text-primary-foreground rounded-br-md"
                                : "bg-card text-foreground border border-border rounded-bl-md"
                            )}
                          >
                            <p className="break-words text-base leading-relaxed">{message.content}</p>
                            <p
                              className={cn(
                                "text-xs mt-1.5 font-medium",
                                isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                              )}
                            >
                              {new Date(message.created_at).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t border-border bg-card">
                  <div className="flex gap-3">
                    <Input
                      placeholder="Type a message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
                      className="flex-1 rounded-xl h-12 text-base border-border"
                    />
                    <Button
                      variant="gradient"
                      size="icon"
                      onClick={sendMessage}
                      disabled={!newMessage.trim()}
                      className="h-12 w-12 rounded-xl shadow-elegant"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center space-y-3">
                  <MessageCircle className="w-20 h-20 mx-auto text-muted-foreground opacity-30" />
                  <p className="text-muted-foreground text-lg">Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
