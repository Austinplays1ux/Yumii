import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Search, UserPlus, MessageCircle as MessageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface UserProfile {
  id: string;
  username: string;
  full_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  isFollowing: boolean;
  postCount: number;
  followerCount: number;
}

export default function Explore() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchUsers = async () => {
    try {
      // Get all profiles except current user
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("id, username, full_name, bio, avatar_url")
        .neq("id", user?.id)
        .limit(50);

      if (error) throw error;

      // For each profile, get follow status, post count, and follower count
      const usersWithDetails = await Promise.all(
        (profiles || []).map(async (profile) => {
          // Check if following
          const { data: followData } = await supabase
            .from("follows")
            .select("id")
            .eq("follower_id", user?.id)
            .eq("following_id", profile.id)
            .single();

          // Get post count
          const { data: posts } = await supabase
            .from("posts")
            .select("id")
            .eq("user_id", profile.id);

          // Get follower count
          const { data: followers } = await supabase
            .from("follows")
            .select("id")
            .eq("following_id", profile.id);

          return {
            ...profile,
            isFollowing: !!followData,
            postCount: posts?.length || 0,
            followerCount: followers?.length || 0,
          };
        })
      );

      setUsers(usersWithDetails);
    } catch (error) {
      toast.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  const toggleFollow = async (userId: string, isFollowing: boolean) => {
    try {
      if (isFollowing) {
        await supabase
          .from("follows")
          .delete()
          .eq("follower_id", user?.id)
          .eq("following_id", userId);
      } else {
        await supabase.from("follows").insert({
          follower_id: user?.id,
          following_id: userId,
        });
      }

      // Update local state
      setUsers(
        users.map((u) =>
          u.id === userId ? { ...u, isFollowing: !isFollowing, followerCount: u.followerCount + (isFollowing ? -1 : 1) } : u
        )
      );

      toast.success(isFollowing ? "Unfollowed" : "Following!");
    } catch (error) {
      toast.error("Failed to update follow status");
    }
  };

  const startConversation = async (otherUserId: string) => {
    try {
      // Check if conversation already exists
      const { data: existingParticipants } = await supabase
        .from("conversation_participants")
        .select("conversation_id")
        .eq("user_id", user?.id);

      if (existingParticipants) {
        for (const participant of existingParticipants) {
          const { data: otherParticipant } = await supabase
            .from("conversation_participants")
            .select("user_id")
            .eq("conversation_id", participant.conversation_id)
            .eq("user_id", otherUserId)
            .single();

          if (otherParticipant) {
            // Conversation exists, navigate to messages
            toast.success("Opening conversation...");
            window.location.href = "/messages";
            return;
          }
        }
      }

      // Create new conversation
      const { data: newConv, error: convError } = await supabase
        .from("conversations")
        .insert({})
        .select()
        .single();

      if (convError) throw convError;

      // Add participants
      await supabase.from("conversation_participants").insert([
        { conversation_id: newConv.id, user_id: user?.id },
        { conversation_id: newConv.id, user_id: otherUserId },
      ]);

      toast.success("Conversation started!");
      window.location.href = "/messages";
    } catch (error) {
      toast.error("Failed to start conversation");
    }
  };

  const filteredUsers = users.filter(
    (u) =>
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 md:pb-6">
      <div className="space-y-3">
        <h1 className="text-4xl font-bold gradient-text">Explore</h1>
        <p className="text-muted-foreground text-lg">Discover and connect with amazing people</p>
      </div>

      {/* Search */}
      <Card className="p-2 rounded-2xl shadow-card border border-border">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-12 border-0 bg-transparent text-base focus-visible:ring-0 focus-visible:ring-offset-0"
          />
        </div>
      </Card>

      {/* Users Grid */}
      <div className="grid gap-4">
        {filteredUsers.map((profile) => (
          <Card
            key={profile.id}
            className="p-6 rounded-2xl shadow-card border border-border hover-lift"
          >
            <div className="flex items-start gap-4">
              <Avatar className="w-16 h-16 ring-4 ring-accent flex-shrink-0">
                <AvatarImage src={profile.avatar_url || undefined} />
                <AvatarFallback className="gradient-brand text-primary-foreground text-xl font-bold">
                  {profile.username[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-lg text-foreground">@{profile.username}</h3>
                {profile.full_name && (
                  <p className="text-muted-foreground font-medium">{profile.full_name}</p>
                )}
                {profile.bio && (
                  <p className="text-sm text-foreground mt-2 line-clamp-2 leading-relaxed">
                    {profile.bio}
                  </p>
                )}

                <div className="flex gap-6 mt-3 text-sm">
                  <span className="font-semibold">
                    <span className="text-foreground text-base">{profile.postCount}</span>{" "}
                    <span className="text-muted-foreground">posts</span>
                  </span>
                  <span className="font-semibold">
                    <span className="text-foreground text-base">{profile.followerCount}</span>{" "}
                    <span className="text-muted-foreground">followers</span>
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-2 flex-shrink-0">
                <Button
                  variant={profile.isFollowing ? "outline" : "gradient"}
                  size="sm"
                  onClick={() => toggleFollow(profile.id, profile.isFollowing)}
                  className={cn(
                    "gap-2 rounded-xl min-w-[110px]",
                    profile.isFollowing && "hover:bg-destructive/10 hover:text-destructive hover:border-destructive"
                  )}
                >
                  <UserPlus className="w-4 h-4" />
                  {profile.isFollowing ? "Following" : "Follow"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => startConversation(profile.id)}
                  className="gap-2 rounded-xl min-w-[110px]"
                >
                  <MessageIcon className="w-4 h-4" />
                  Message
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {filteredUsers.length === 0 && (
          <Card className="text-center py-16 rounded-2xl shadow-card border border-border">
            <div className="space-y-2">
              <p className="text-lg font-semibold text-foreground">No users found</p>
              <p className="text-muted-foreground">Try a different search term</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
