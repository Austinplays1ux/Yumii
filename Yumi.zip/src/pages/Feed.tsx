import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageCircle as MessageIcon, Share2, Send } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Post {
  id: string;
  caption: string;
  image_url: string | null;
  created_at: string;
  user_id: string;
  profiles: {
    username: string;
    avatar_url: string | null;
    full_name: string | null;
  };
  likes: { id: string; user_id: string }[];
  _count?: { likes: number };
}

export default function Feed() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPost, setNewPost] = useState("");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    fetchPosts();

    // Subscribe to new posts
    const channel = supabase
      .channel("posts-channel")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "posts" },
        () => {
          fetchPosts();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(
          `
          *,
          profiles (username, avatar_url, full_name),
          likes (id, user_id)
        `
        )
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      toast.error("Failed to load posts");
    } finally {
      setLoading(false);
    }
  };

  const createPost = async () => {
    if (!newPost.trim()) return;

    setPosting(true);
    try {
      const { error } = await supabase.from("posts").insert({
        caption: newPost,
        user_id: user?.id,
      });

      if (error) throw error;

      setNewPost("");
      toast.success("Post created!");
    } catch (error) {
      toast.error("Failed to create post");
    } finally {
      setPosting(false);
    }
  };

  const toggleLike = async (postId: string, isLiked: boolean) => {
    try {
      if (isLiked) {
        await supabase.from("likes").delete().match({ post_id: postId, user_id: user?.id });
      } else {
        await supabase.from("likes").insert({ post_id: postId, user_id: user?.id });
      }
      fetchPosts();
    } catch (error) {
      toast.error("Failed to update like");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 md:pb-6">
      {/* Create Post */}
      <Card className="p-6 rounded-2xl shadow-card border border-border hover-lift">
        <div className="flex gap-4">
          <Avatar className="w-12 h-12 ring-2 ring-accent">
            <AvatarFallback className="gradient-brand text-primary-foreground font-semibold">
              {user?.email?.[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-3">
            <Textarea
              placeholder="What's on your mind?"
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              className="min-h-[100px] resize-none rounded-xl border-border focus:border-primary transition-smooth text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-sm text-muted-foreground">Share your thoughts with the community</p>
              <Button
                variant="gradient"
                size="default"
                onClick={createPost}
                disabled={posting || !newPost.trim()}
                className="gap-2 px-6"
              >
                <Send className="w-4 h-4" />
                Post
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Posts Feed */}
      <div className="space-y-6">
        {posts.map((post) => {
          const isLiked = post.likes.some((like) => like.user_id === user?.id);
          const likeCount = post.likes.length;

          return (
            <Card key={post.id} className="p-6 rounded-2xl shadow-card border border-border hover-lift">
              {/* User Header */}
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-12 h-12 ring-2 ring-accent">
                  <AvatarImage src={post.profiles?.avatar_url || undefined} />
                  <AvatarFallback className="gradient-brand text-primary-foreground font-semibold">
                    {post.profiles?.username?.[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-bold text-foreground">{post.profiles?.username}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(post.created_at).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </p>
                </div>
              </div>

              {/* Caption */}
              {post.caption && (
                <p className="text-foreground mb-4 whitespace-pre-wrap text-base leading-relaxed">
                  {post.caption}
                </p>
              )}

              {/* Actions */}
              <div className="flex items-center gap-2 pt-4 border-t border-border">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleLike(post.id, isLiked)}
                  className={cn(
                    "gap-2 hover:bg-accent rounded-xl px-4",
                    isLiked && "text-primary hover:text-primary"
                  )}
                >
                  <Heart className={cn("w-5 h-5 transition-bounce", isLiked && "fill-current scale-110")} />
                  <span className="font-semibold">{likeCount}</span>
                </Button>
                <Button variant="ghost" size="sm" className="gap-2 hover:bg-accent rounded-xl px-4">
                  <MessageIcon className="w-5 h-5" />
                  <span className="font-semibold">Comment</span>
                </Button>
                <Button variant="ghost" size="sm" className="gap-2 hover:bg-accent rounded-xl px-4 ml-auto">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {posts.length === 0 && (
        <Card className="text-center py-16 rounded-2xl shadow-card border border-border">
          <div className="space-y-2">
            <p className="text-lg font-semibold text-foreground">No posts yet</p>
            <p className="text-muted-foreground">Be the first to share something!</p>
          </div>
        </Card>
      )}
    </div>
  );
}
